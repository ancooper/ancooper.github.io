extends Camera2D

@export var min_position: Node2D
@export var max_position: Node2D
@export var player: Node2D
@export var speed: float

func _physics_process(delta: float) -> void:
	if not player:
		return
	global_position = global_position.move_toward(player.global_position, speed * delta)
	if global_position.x < min_position.global_position.x:
		global_position.x = min_position.global_position.x
	if global_position.y < min_position.global_position.y:
		global_position.y = min_position.global_position.y
	if global_position.x > max_position.global_position.x:
		global_position.x = max_position.global_position.x
	if global_position.y > max_position.global_position.y:
		global_position.y = max_position.global_position.y
	global_position = global_position.floor()
