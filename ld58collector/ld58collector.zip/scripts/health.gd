class_name Health extends Node2D

var value: int = 3

@onready var sprite_2d: Sprite2D = $Sprite2D
@onready var sprite_2d_2: Sprite2D = $Sprite2D2
@onready var sprite_2d_3: Sprite2D = $Sprite2D3

func _ready() -> void:
	G.health = self

func take_damage() -> bool:
	Audio.stream_player_one_shot(Audio.DAMAGE, Audio.SFX_BUS)
	match value:
		3: sprite_2d_3.visible = false
		2: sprite_2d_2.visible = false
		1: sprite_2d.visible = false
	value -= 1
	return value > 0
