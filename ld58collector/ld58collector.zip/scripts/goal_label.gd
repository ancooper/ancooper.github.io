class_name GoalLabel extends RichTextLabel

var template: String

func _ready() -> void:
	template = text
	refresh("", "")
	G.goal_label = self


func refresh(goal: String, current: String) -> void:
	text = template % [goal, current]
