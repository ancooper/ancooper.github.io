class_name Key extends TextureRect

@export var type: KeyQueue.Type
