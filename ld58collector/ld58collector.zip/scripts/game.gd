class_name Game extends Node2D

@export var goal_tscn: PackedScene
@export var goal_spawn_position: Node2D

@onready var post_process: PostProcess = $PostProcessLayer

@export var world: TileMapLayer
@export var player: Player

@onready var camera: Camera2D = $Camera2D
@onready var defeat_screen: Panel = $Camera2D/DefeatScreen
@onready var win_screen: Panel = $Camera2D/WinScreen

func _ready() -> void:
	defeat_screen.visible = false
	win_screen.visible = false
	G.game = self
	G.world = world
	world.visible = true
	await post_process.fade_out(1.2)
	G.start()

func spawn_goal(goal: Array) -> void:
	var new_goal = goal_tscn.instantiate() as GoalValue
	camera.add_child(new_goal)
	new_goal.position = goal_spawn_position.position
	new_goal.timeout.connect(G.take_damage)
	new_goal.make(goal, goal.size() * 5.0 + 5.0)

func restart() -> void:
	await post_process.fade_in(1.2)
	get_tree().reload_current_scene()


func defeat_screen_show() -> void:
	defeat_screen.visible = true

func win_screen_show() -> void:
	win_screen.visible = true


func _process(delta: float) -> void:
	if (defeat_screen.visible or win_screen.visible) and Input.is_action_just_pressed("space"):
		restart()
