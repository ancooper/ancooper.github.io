class_name KeyQueue extends Node2D

enum Type {RED, BLUE, YELLOW, GREEN, WHITE}

@export var trail_tscn: PackedScene
@export var slide_curve: Curve

@onready var frame: NinePatchRect = $Frame

var size: int = 3
var items: Array[Type]
var keys: Array[TextureRect]
var current: Type
var busy: bool = false
var shift: float = -60
var key_offset: Vector2 = Vector2(-57.0, 10.0)

var complete: bool = false

static var PREFABS: Dictionary[Type, PackedScene] = {
	Type.RED: preload("res://scenes/keys/red.tscn"),
	Type.BLUE: preload("res://scenes/keys/blue.tscn"),
	Type.YELLOW: preload("res://scenes/keys/yellow.tscn"),
	Type.GREEN: preload("res://scenes/keys/green.tscn"),
	Type.WHITE: preload("res://scenes/keys/white.tscn"),
}


func _ready() -> void:
	G.key_queue = self
	items = []
	keys = []


func spawn_star(player_position: Vector2) -> void:
	var star = trail_tscn.instantiate()
	add_child(star)
	await (star as Trail).anim(player_position + Vector2(0.0, -50.0), global_position + Vector2(absf(shift) * (float(size) + 1.0) * 0.5, 30.0))


func add(key: Type) -> void:
	prints("[key_queue:30]", "add key", key)
	items.append(key)

func resize() -> void:
	key_offset = Vector2(float(size) * shift * 0.5 + 3.0, 12)
	frame.size = Vector2(absf(shift) * (float(size) + 0.5), 60.0)
	frame.position = Vector2(-frame.size.x * 0.5, 0.0)


func _process(delta: float) -> void:
	resize()
	
	#if Input.is_action_just_pressed("ui_cancel"):
		#complete = true
	
	if not busy and complete:
		complete = false
		prints("[key_queue:24]", "complete")
		while keys.size() > 0:
			var drop_key = keys.pop_front()
			_destroy_key(drop_key)
	
	if not busy and items.size() > 0:
		prints("[key_queue:33]", "size", keys.size())
		_start_add_key_sequence()
	
	#if Input.is_action_just_pressed("ui_accept"):
		#items.append(Type.RED)


func _start_add_key_sequence() -> void:
	busy = true
	current = items.pop_front()
	
	#======== new key
	var new_key = PREFABS[current].instantiate()
	add_child(new_key)
	new_key.position = Vector2(0, 0) + key_offset
	keys.append(new_key)
	#await new_key.effect
	
	#========= move keys
	var t = get_tree().create_tween()
	t.tween_method(_move_keys, 0.0, 1.0, 0.33)
	await t.finished
	_move_keys_final()
	
	while keys.size() > size:
		var drop_key = keys.pop_front()
		_destroy_key(drop_key)
	#await get_tree().create_timer(0.25).timeout
	test_goal()
	busy = false


func test_goal() -> void:
	var key_types = keys.map(func(key): return (key as Key).type)
	key_types.reverse()
	if G.goal_complete(key_types):
		prints("[key_queue:91]", "goal complete")
		while keys.size() > 0:
			var drop_key = keys.pop_front()
			_destroy_key(drop_key)
		await G.next_goal(true)


func _move_keys(value: float) -> void:
	for i in range(keys.size()):
		keys[i].position = Vector2((slide_curve.sample_baked(value) - i - (size - keys.size() + 1)) * shift + 10, 0.0) + key_offset

func _move_keys_final() -> void:
	for i in range(keys.size()):
		keys[i].position = Vector2((1.0 - i - (size - keys.size() + 1)) * shift + 10, 0.0) + key_offset


func _destroy_key(key: TextureRect) -> void:
	#await destroy anim
	var t = get_tree().create_tween()
	t.tween_method(func(v: float): key.modulate = Color(1, 1, 1, v), 1.0, 0.0, 0.33)
	await t.finished
	key.queue_free()
