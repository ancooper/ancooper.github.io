class_name Trail extends Node2D

@export var x_path: Curve
@export var y_path: Curve
@export var s_path: Curve

@onready var star: Sprite2D = $star

var start: Vector2
var end: Vector2

func anim(_start: Vector2, _end: Vector2) -> void:
	start = _start
	end = _end
	var t = get_tree().create_tween()
	t.tween_method(_move, 0.0, 1.0, 0.125 * start.distance_to(end) * 0.005)
	await  t.finished
	queue_free()

func _move(value: float) -> void:
	var pos = start + (end - start) * Vector2(x_path.sample_baked(value), y_path.sample_baked(value))
	star.scale = Vector2.ONE * s_path.sample_baked(value) * 1.0
	star.rotation = (value) * 3.0
	star.global_position = pos
