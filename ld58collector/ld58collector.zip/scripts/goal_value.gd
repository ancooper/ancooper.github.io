class_name GoalValue extends Node2D

@onready var frame: NinePatchRect = $Frame
@onready var particles1: GPUParticles2D = $GPUParticles2D
@onready var particles2: GPUParticles2D = $GPUParticles2D2

@onready var timeout_frame: NinePatchRect = $Timeout
@onready var base_color: ColorRect = $Timeout/BaseColor
@onready var time_color: ColorRect = $Timeout/BaseColor/TimeColor

var shift: float = -60
var key_offset: Vector2 = Vector2(-57, 12)

var size: int = 3
var items: Array[KeyQueue.Type]

signal timeout

func _ready() -> void:
	G.goal_value = self
	set_frame_size()
	set_timeout(0.5)

func set_frame_size() -> void:
	frame.size = Vector2(absf(shift) * (float(size) + 0.5), 60.0)
	frame.position = Vector2(-frame.size.x * 0.5, 0.0)
	particles1.position.x = -frame.size.x * 0.5 + 5.0
	particles2.position.x = frame.size.x * 0.5 - 5.0
	timeout_frame.size.x = frame.size.x
	timeout_frame.size.y = 30
	timeout_frame.position = Vector2(-frame.size.x * 0.5, 60.0)
	set_timeout(0.50)


func set_timeout(value: float) -> void:
	base_color.size = timeout_frame.size - Vector2(12.0, 12.0)
	time_color.size.x = floorf((base_color.size.x - 4.0) * value * 0.5) * 2.0
	time_color.size.y = base_color.size.y - 4.0
	time_color.position.x = (base_color.size.x - time_color.size.x) * 0.5 
	time_color.position.y = 2.0

var t: Tween
func make(goal: Array, duration: float) -> void:
	items = []
	for item in goal:
		items.append(G.COLLECT[item])
	size = items.size()
	set_frame_size()
	
	for i in range(items.size()):
		var new_key = KeyQueue.PREFABS[items[i]].instantiate()
		add_child(new_key)
		new_key.position = Vector2((i - size * 0.5) * shift + 10, 0.0) + key_offset
	
	t = get_tree().create_tween()
	t.tween_method(set_timeout, 1.0, 0.0, duration)
	await t.finished
	timeout.emit()

func complete() -> void:
	if is_instance_valid(t):
		t.kill()
	
	Audio.stream_player_one_shot(Audio.COMPLETE, Audio.SFX_BUS)
	particles1.restart()
	particles2.restart()
	particles1.emitting = true
	particles2.emitting = true
	await get_tree().create_timer(0.5).timeout
