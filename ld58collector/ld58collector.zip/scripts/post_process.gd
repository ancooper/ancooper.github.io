class_name PostProcess extends CanvasLayer

@onready var post_process: ColorRect = $PostProcess


func _ready() -> void:
	visible = true


func fade_in(time: float) -> void:
	var tween = create_tween()
	tween.tween_method(_fade, 0.0, 1.0, time)
	await tween.finished


func fade_out(time: float) -> void:
	var tween = create_tween()
	tween.tween_method(_fade, 1.0, 0.0, time)
	await tween.finished


func _fade(value: float) -> void:
	post_process.material.set_shader_parameter("dissolve_value", value)
