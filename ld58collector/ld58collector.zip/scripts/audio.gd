class_name Audio extends Node2D

const AUDIO_FILE: StringName = &"user://audio.json"

const MASTER_BUS = &"Master"
const MUSIC_BUS = &"Music"
const SFX_BUS = &"SFX"

const COMPLETE = &"Complete"
const DAMAGE = &"Damage"
const PICKUP = &"Pickup"
const RECALL = &"Recall"
const STAIRS = &"Stairs"
const STEPS = &"Steps"

const streams_preload = {
	COMPLETE: preload("res://assets/audios/complete.mp3"),
	DAMAGE: preload("res://assets/audios/damage.mp3"),
	PICKUP: preload("res://assets/audios/pickup.mp3"),
	RECALL: preload("res://assets/audios/recall.mp3"),
	STAIRS: preload("res://assets/audios/stairs.mp3"),
	STEPS: preload("res://assets/audios/steps.mp3"),
}

static var _scene: Node
static var typing_audio_stream: AudioStreamPlayer2D
static var stream_players: Dictionary[StringName, AudioStreamPlayer2D] = {}


func _ready() -> void:
	_load()
	G.audio = self
	stream_scene(self);


static func _load() -> void:
	var loaded_data = null
	var load_file = FileAccess.open(AUDIO_FILE, FileAccess.READ)
	if load_file:
		loaded_data = JSON.parse_string(load_file.get_as_text())
		load_file.close()
	if loaded_data and loaded_data.has(Audio.SFX_BUS) and loaded_data.has(Audio.MUSIC_BUS):
		var sound_volume = loaded_data[Audio.SFX_BUS]
		set_volume(sound_volume, Audio.SFX_BUS)
		var music_volume = loaded_data[Audio.MUSIC_BUS]
		set_volume(music_volume, Audio.MUSIC_BUS)
	else:
		save()


static func save() -> void:
	var file = FileAccess.open(AUDIO_FILE, FileAccess.WRITE)
	var sound_volume = get_volume(Audio.SFX_BUS)
	var music_volume = get_volume(Audio.MUSIC_BUS)
	file.store_string(JSON.stringify({Audio.SFX_BUS: sound_volume, Audio.MUSIC_BUS: music_volume}))
	file.flush()
	file.close()


static func stream_scene(parent: Node = null) -> Node:
	if !_scene:
		if parent:
			_scene = parent
		else:
			_scene = Engine.get_main_loop().current_scene;
	return _scene


static func _stream_singleton(stream_name: StringName, bus: StringName = MASTER_BUS, parent: Node = null, loop: bool = false, one_shot: bool = false) -> AudioStreamPlayer2D:
	if !streams_preload.has(stream_name):
		return null
	
	streams_preload[stream_name].loop = loop
	
	if one_shot:
		var stream_player = AudioStreamPlayer2D.new()
		stream_player.stream = streams_preload[stream_name]
		stream_player.bus = bus
		stream_player.panning_strength = 0.0
		stream_scene(parent).add_child(stream_player)
		stream_player.finished.connect(stream_player.queue_free)
		return stream_player
	
	if stream_players.has(stream_name):
		if not stream_players[stream_name]:
			stream_players.erase(stream_name)
	
	if !stream_players.has(stream_name):
		var stream_player = AudioStreamPlayer2D.new()
		stream_player.stream = streams_preload[stream_name]
		stream_player.bus = bus
		stream_player.panning_strength = 0.0
		stream_scene(parent).add_child(stream_player)
		stream_players[stream_name] = stream_player
	return stream_players[stream_name]


static func stream_player_start_here(node: Node, stream_name: StringName, bus: StringName = MASTER_BUS, loop: bool = false, rnd_seek: bool = false, one_shot: bool = false) -> void:
	var stream_player = Audio._stream_singleton(stream_name, bus, node, loop, one_shot)
	if stream_player:
		if one_shot:
			stream_player.play()
		else:
			var seek: float = 0
			if rnd_seek:
				seek = randf() * stream_player.stream.get_length()
			stream_player.play(seek)


static func stream_player_start(stream_name: StringName, bus: StringName = MASTER_BUS, loop: bool = false, rnd_seek: bool = false) -> void:
	var stream_player = Audio._stream_singleton(stream_name)
	if not stream_player:
		stream_player_start_here(null, stream_name, bus, loop, rnd_seek)


static func stream_player_one_shot(stream_name: StringName, bus: StringName = MASTER_BUS) -> void:
	stream_player_start_here(null, stream_name, bus, false, false, true)


static func stream_player_stop(stream_name: StringName) -> void:
	var stream_player = Audio._stream_singleton(stream_name)
	if stream_player:
		stream_player.stop()


static func get_volume(bus: StringName = MASTER_BUS) -> float:
	var db = AudioServer.get_bus_volume_db(AudioServer.get_bus_index(bus))
	return remap(clamp(db, -40.0, 6.0), -40.0, 6.0, 0.0, 100.0)


static func set_volume(volume: float, bus: StringName = MASTER_BUS) -> void:
	var db = remap(clamp(volume, 0.0, 100.0), 0.0, 100.0, -40.0, 6.0)
	AudioServer.set_bus_volume_db(AudioServer.get_bus_index(bus), db)
