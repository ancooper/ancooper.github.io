extends CharacterBody2D

enum Style {HORIZONTAL, VERTICAL}

@export_category("Enemy movement")
@export var target: Node2D
@export var speed: Vector2 = Vector2(400.0, 300.0)
@export var direction_style: Style = Style.HORIZONTAL

@onready var world: TileMapLayer = $"../world"

var on_stair: bool = false
var h_factor: float = 0

# var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")

#func get_input() -> Vector2:
	#return Input.get_vector("left", "right", "up", "down")

#var last_position: Vector2
#var last_on_stair: bool = false
func _physics_process(delta: float) -> void:
	var target_offset: Vector2 = target.global_position - global_position
	
	var input_h = 0
	var input_v = 0
	if direction_style == Style.HORIZONTAL:
		if absf(target_offset.x) > 5.0:
			input_h = signf(target_offset.x)
		else:
			input_v = signf(target_offset.y)
	if direction_style == Style.VERTICAL:
		if absf(target_offset.y) > 5.0:
			input_v = signf(target_offset.y)
		else:
			input_h = signf(target_offset.x)

	h_factor *= 0.9
	if is_on_floor() or on_stair:
		h_factor = 1

	if input_h != 0:
		velocity.x = input_h * speed.x * h_factor
	else:
		velocity.x = move_toward(velocity.x, 0, speed.x)
	
	
	if on_stair:
		velocity.y = input_v * speed.y
	
	if not is_on_floor() and not on_stair:
		velocity.y = speed.y
	
	move_and_slide()


func _on_area_2d_body_entered(body: Node2D) -> void:
	on_stair = true


func _on_area_2d_body_exited(body: Node2D) -> void:
	on_stair = false
