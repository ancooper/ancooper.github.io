extends Node

const KEY_COORD: Dictionary[int, Vector2i] = {
	1: Vector2i(0, 11),
	2: Vector2i(1, 11),
	3: Vector2i(2, 11),
	4: Vector2i(3, 11),
	5: Vector2i(4, 11),
}
const STAND_COORD: Dictionary[int, Vector2i] = {
	1: Vector2i(0, 10),
	2: Vector2i(1, 10),
	3: Vector2i(2, 10),
	4: Vector2i(3, 10),
	5: Vector2i(4, 10),
}
const COLLECT: Dictionary[int, KeyQueue.Type] = {
	1: KeyQueue.Type.RED,
	2: KeyQueue.Type.BLUE,
	3: KeyQueue.Type.YELLOW,
	4: KeyQueue.Type.GREEN,
	5: KeyQueue.Type.WHITE,
}

var audio: Audio
var game: Game
var world: TileMapLayer
var player: Player
var health: Health
var goal_value: GoalValue
var key_queue: KeyQueue
var goal_label: GoalLabel
var collected_list: Array[int] = []
var current_goal_id = 0
var goals: Array = [
	[2],
	[3],
	[1],
	[1, 2],
	[3, 2],
	[2, 1],
	[1, 3],
	[2, 3],
	[3, 1],
	[3, 2, 1],
	[3, 1, 2],
	[2, 3, 1],
	[2, 1, 3],
	[2, 3, 4],
	[1, 2, 1],
	[2, 3, 2, 1],
	[3, 1, 2, 4],
	[3, 2, 3, 2, 1],
	[4, 1, 2, 3, 2],
	[4, 1, 2, 1, 3],
	[2, 1, 2, 3, 2],
	[4, 1, 2, 3, 2, 1, 3]
]

func start() -> void:
	current_goal_id = 0
	await get_tree().create_timer(0.1).timeout
	show_goal()
	Audio._scene = player


func current_goal() -> Array:
	if goals.size() > current_goal_id:
		return goals[current_goal_id]
	return []

func collected(collectable: int) -> void:
	await key_queue.spawn_star(player.global_position)
	#await get_tree().create_timer(0.2).timeout
	key_queue.add(COLLECT[collectable])
	
	#collected_list.append(collectable)
	#while collected_list.size() > current_goal().size():
		#collected_list.pop_front()
	#show_goal()
	#if list_to_str(current_goal()) == list_to_str(collected_list):
		#current_goal_id += 1
		#collected_list.clear()
		#await get_tree().create_timer(0.3).timeout
		#show_goal()
	

func wait_and_respawn(ceil_coolrs: Vector2i, collectable: int) -> void:
	world.set_cell(ceil_coolrs, 0, STAND_COORD[collectable])
	await get_tree().create_timer(5.0).timeout
	Audio.stream_player_one_shot(Audio.RECALL, Audio.SFX_BUS)
	world.set_cell(ceil_coolrs, 0, KEY_COORD[collectable])


func list_to_str(list: Array) -> String:
	return ""


func take_damage() -> void:
	if health.take_damage():
		next_goal(false)
	else:
		defeat()


func defeat() -> void:
	player.queue_free()
	game.defeat_screen_show()
	#game.restart()


func show_goal() -> void:
	game.spawn_goal(current_goal())
	key_queue.size = current_goal().size()
	key_queue.visible = true
	key_queue.resize()

	key_queue.test_goal()
	
	if goal_label:
		var goal = list_to_str(current_goal())
		var curr = list_to_str(collected_list)
		goal_label.refresh(goal, curr)


func goal_complete(types: Array) -> bool:
	var goal = current_goal().map(func(i): return COLLECT[i] as KeyQueue.Type)
	if goal.size() != types.size():
		return false
	for i in range(goal.size()):
		if goal[i] != types[i]:
			return false
	return true


func next_goal(good: bool) -> void:
	if good:
		await goal_value.complete()
	goal_value.queue_free()
	current_goal_id += 1
	if current_goal_id >= goals.size():
		key_queue.size = 1
		game.win_screen_show()
		return
	show_goal()
