class_name Player extends CharacterBody2D

@export_category("Player movement")
@export var speed: Vector2 = Vector2(400.0, 300.0)

@onready var world: TileMapLayer = $"../world"
@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

const TOP_STAIR = Vector2i(1, 8)
const RED_KEY = Vector2i(1, 10)
const RED_KEY_STAND = Vector2i(0, 10)


var on_stair: bool = false
var on_stair_top: bool = false
var h_factor: float = 0

func _ready() -> void:
	G.player = self

# var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")

#func get_input() -> Vector2:
	#return Input.get_vector("left", "right", "up", "down")

#var last_position: Vector2
#var last_on_stair: bool = false
func _physics_process(delta: float) -> void:
	on_top_stairs_test()
	var input_h = Input.get_axis("left", "right")
	
	var input_v = Input.get_axis("up", "down")
	if on_stair_top and input_v < 0:
		input_v = 0
		

	h_factor *= 0.9
	if is_on_floor() or on_stair:
		h_factor = 1

	if input_h != 0:
		velocity.x = input_h * speed.x * h_factor
	else:
		velocity.x = move_toward(velocity.x, 0, speed.x)
	$CameraFollow.position.x = signf(input_h) * 200.0 * h_factor
	if absf(velocity.x) < 10:
		anim.play("idle")
		Audio.stream_player_stop(Audio.STEPS)
	else:
		if velocity.x > 0:
			anim.play("run_right")
		else:
			anim.play("run_left")
		if is_on_floor():
			Audio.stream_player_start(Audio.STEPS, Audio.SFX_BUS, true)
	
	if on_stair and not is_on_floor():
		if anim.animation != "stair":
			anim.play("stair")
	
	if on_stair:
		velocity.y = input_v * speed.y
	
	if not is_on_floor() and not on_stair:
		velocity.y = speed.y
	
	move_and_slide()
	collectable_interract()


func on_top_stairs_test() -> void:
	var cell_coords = world.local_to_map(world.to_local(global_position))
	var tile_data = world.get_cell_atlas_coords(cell_coords)
	on_stair_top = tile_data == TOP_STAIR


func collectable_interract() -> void:
	var cell_coords = world.local_to_map(world.to_local(global_position))
	var tile_data = world.get_cell_tile_data(cell_coords)
	if tile_data:
		var collectable = tile_data.get_custom_data("Collectable")
		if collectable > 0:
			collect(cell_coords, collectable)


func collect(ceil_coolrs: Vector2i, collectable: int) -> void:
	#prints("[player:49]", "Collect %d" % collectable)
	Audio.stream_player_one_shot(Audio.PICKUP, Audio.SFX_BUS)
	G.collected(collectable)
	G.wait_and_respawn(ceil_coolrs, collectable)


func _on_area_2d_body_entered(body: Node2D) -> void:
	on_stair = true


func _on_area_2d_body_exited(body: Node2D) -> void:
	on_stair = false
