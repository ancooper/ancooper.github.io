@tool
class_name PrintHelper extends EditorScript

func _run():
	var editor = get_editor_interface()
	var script_editor = editor.get_script_editor()
	var script_name = script_editor.get_current_script().resource_path.get_file().get_basename()
	var script_text_editor = script_editor.get_current_editor().get_base_editor() as TextEdit
	var line = script_text_editor.get_caret_line()
	var indent = script_text_editor.get_indent_level(line) / script_text_editor.get_tab_size()
	var text = "\t".repeat(indent) + "prints(\"[%s:%d]\", " % [script_name, line + 1]
	script_text_editor.begin_complex_operation()
	script_text_editor.insert_line_at(line, text)
	script_text_editor.set_caret_line(line)
	script_text_editor.set_caret_column(text.length())
	script_text_editor.end_complex_operation()
