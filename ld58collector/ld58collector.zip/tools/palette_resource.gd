@tool                                   # если хотите редактировать в редакторе
class_name PaletteResource               # делает тип доступным как «PaletteResource» в инспекторе
extends Resource

# Поле, которое будет хранить набор цветов
@export var colors : PackedColorArray = []
