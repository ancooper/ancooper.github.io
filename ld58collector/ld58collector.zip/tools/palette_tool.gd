@tool
class_name PaletteTool extends EditorScript

var window: Window
var path_edit : LineEdit
var file_dialog : EditorFileDialog
var file_dialog_res : EditorFileDialog
var text_edit   : TextEdit 

func _run() -> void:
	# ------------------------------
	# 1️⃣ Окно
	# ------------------------------
	window = Window.new()
	window.title = "Palette tool"
	window.popup_window = true          # окно будет всплывающим
	window.size = Vector2(360, 640)
	window.min_size = window.size
	window.close_requested.connect(func(): 
		if is_instance_valid(file_dialog):
			file_dialog.queue_free()
		window.queue_free()
	)

	# ------------------------------
	# 2️⃣ Корневой контейнер внутри окна
	# ------------------------------
	var root = VBoxContainer.new()
	# 1️⃣ Включаем заполнение всего окна (0‑1 – полные диапазоны)
	root.anchor_left   = 0.0      # левый край привязан к левому краю окна
	root.anchor_top    = 0.0      # верхний к верхнему
	root.anchor_right  = 1.0      # правый к правому
	root.anchor_bottom = 1.0      # нижний к нижнему

	# 2️⃣ Добавляем свои отступы (по‑усмотрению)
	root.offset_left   = 10   # 10 px от левого края окна
	root.offset_top    = 10
	root.offset_right  = -10  # отрицательное значение = отступ от правого края
	root.offset_bottom = -10
	
	window.add_child(root)

	# ------------------------------
	# 3️⃣ UI‑элементы для выбора файла
	# ------------------------------
	# Подпись
	var lbl = Label.new()
	lbl.text = "Выберите файл ресурса:"
	root.add_child(lbl)

	# Поле ввода пути
	path_edit = LineEdit.new()
	path_edit.placeholder_text = "Путь к файлу..."
	path_edit.expand_to_text_length = true
	root.add_child(path_edit)


	# Кнопка, открывающая диалог
	var btn_browse = Button.new()
	btn_browse.text = "Обзор…"
	btn_browse.pressed.connect(_on_browse_pressed)
	root.add_child(btn_browse)
	
	
	# ---------------------------------------------------------
	# 4️⃣ МНОГОСТРОЧНОЕ ТЕКСТОВОЕ ПОЛЕ
	# ---------------------------------------------------------
	var txt_label = Label.new()
	txt_label.text = "Содержимое файла:"
	#txt_label.margin_top = 10 <- Нет такого свойства
	root.add_child(txt_label)

	text_edit = TextEdit.new()
	text_edit.size_flags_vertical   = Control.SIZE_EXPAND_FILL
	text_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_edit.wrap_mode = TextEdit.LINE_WRAPPING_NONE
	#text_edit.scroll_fit_content_height = true
	#text_edit.focus_mode = Control.FOCUS_ALL
	root.add_child(text_edit)

	# Кнопка, читающая выбранный файл
	var btn_make_palette = Button.new()
	btn_make_palette.text = "Создать палитру"
	btn_make_palette.pressed.connect(_on_make_palette_pressed)
	root.add_child(btn_make_palette)

	# ------------------------------
	# 4️⃣ Диалог выбора файла
	# ------------------------------
	file_dialog = EditorFileDialog.new()
	# Если нужен конкретный тип (например, *.png):
	file_dialog.add_filter("*.hex ; HEX palette")
	# Можно разрешить любые типы:
	file_dialog.access = EditorFileDialog.ACCESS_RESOURCES   # ищет в проекте
	file_dialog.file_mode = EditorFileDialog.FILE_MODE_OPEN_FILE
	file_dialog.file_selected.connect(_on_file_selected)
	# При закрытии без выбора (чтобы не оставлять диалог в сцене)
	file_dialog.close_requested.connect(func():
		file_dialog.release_focus()
	)
	window.add_child(file_dialog)

	# ------------------------------
	# 4️⃣ Диалог выбора ресурса
	# ------------------------------
	file_dialog_res = EditorFileDialog.new()
	file_dialog_res.add_filter("*.tres ; Palette resource")
	# Можно разрешить любые типы:
	file_dialog_res.access = EditorFileDialog.ACCESS_RESOURCES   # ищет в проекте
	file_dialog_res.file_mode = EditorFileDialog.FILE_MODE_SAVE_FILE
	file_dialog_res.file_selected.connect(_on_file_res_selected)
	# При закрытии без выбора (чтобы не оставлять диалог в сцене)
	file_dialog_res.close_requested.connect(func():
		file_dialog_res.release_focus()
	)
	window.add_child(file_dialog_res)

	# ------------------------------
	# 5️⃣ Показать окно в центре редактора
	# ------------------------------
	EditorInterface.popup_dialog_centered(window, window.size)


# -----------------------------------------------------------------
# СЛОТОВЫЕ функции (сигналы)
# -----------------------------------------------------------------
func _on_browse_pressed() -> void:
	if not is_instance_valid(file_dialog):
		return
	
	# Если в поле уже есть путь, откроем диалог в этой папке
	var start_path = path_edit.text.strip_edges()
	if start_path != "":
		var dir = start_path.get_base_dir()
		if DirAccess.dir_exists_absolute(dir):
			file_dialog.current_path = dir
	
	file_dialog.popup_centered()


func _on_make_palette_pressed() -> void:
	if not is_instance_valid(file_dialog_res):
		return
	
	file_dialog_res.popup_centered()


func _on_open_pressed() -> void:
	_open_file(path_edit.text)


func _on_file_selected(path: String) -> void:
	# 1️⃣ Заполняем LineEdit
	path_edit.text = path
	_open_file(path)


func _open_file(path: String) -> void:
	if path == "":
		push_warning("Файл не выбран")
		return
	
	# 2️⃣ Читаем файл и выводим в TextEdit
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		push_error("Не удалось открыть файл: %s" % path)
		return

	var content := file.get_as_text()
	file.close()

	text_edit.text = content   # <-- отобразили содержимое

	# Если хотите сразу установить курсор в начало:
	text_edit.set_caret_column(0)
	text_edit.set_caret_line(0)


func _on_file_res_selected(path: String) -> void:
	var colors: PackedColorArray = []
	for line in text_edit.text.split("\n"):
		if Color.html_is_valid("#" + line.replace("#", "")):
			var color = Color.html("#" + line.replace("#", ""))
			colors.append(color)
	if colors.size() == 0:
		push_warning("Цвета не найдены")
		return
	_make_palette(path, colors)


func _make_palette(save_path: String, colors: PackedColorArray) -> void:
	# 1️⃣ Создаём объект нашего ресурса
	var palette_res := PaletteResource.new()
	
	# 2️⃣ Заполняем массивом цветов
	palette_res.colors = colors.duplicate()   # дублируем, чтобы не привязывать к исходному массиву
	
	# 3️⃣ Формируем путь к файлу.
	#    Если пользователь передаёт путь к *.hex* – сохраняем рядом с тем же именем,
	#    но с расширением *.tres* (можно менять на *.res* или свой .palette).
	var target_path : String = save_path.get_basename() + ".tres"
	
	# 4️⃣ Сохраняем ресурс.
	var err := ResourceSaver.save(palette_res, target_path)
	if err != OK:
		push_error("Не удалось сохранить палитру в %s (ошибка %d)" % [target_path, err])
	else:
		print("Палитра успешно сохранена: %s" % target_path)


# -------------------------------------------------------------
# Дополнительно: Сохранить отредактированный текст обратно
# -------------------------------------------------------------
func _save_current_file() -> void:
	if path_edit.text == "":
		push_warning("Нет выбранного файла для сохранения.")
		return

	var file := FileAccess.open(path_edit.text, FileAccess.WRITE)
	if file == null:
		push_error("Не удалось открыть файл для записи: %s" % path_edit.text)
		return

	file.store_string(text_edit.text)
	file.close()
	print("Файл сохранён: %s" % path_edit.text)


# -------------------------------------------------------------
# Кнопка «Сохранить» (если понадобится)
# -------------------------------------------------------------
func _add_save_button(root: VBoxContainer) -> void:
	var save_btn = Button.new()
	save_btn.text = "Сохранить"
	save_btn.alignment = HORIZONTAL_ALIGNMENT_RIGHT
	#save_btn.margin_top = 10 <- Нет такого свойства
	save_btn.pressed.connect(_save_current_file)
	root.add_child(save_btn)
